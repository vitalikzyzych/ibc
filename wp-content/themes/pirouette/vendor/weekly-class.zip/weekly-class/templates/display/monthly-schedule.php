<?php

	if( ! wp_style_is( 'wcs-display-monthly' ) )
		wp_enqueue_style( 'wcs-display-monthly' );
?>
<div class="wcs-timetable wcs-timetable__monthly-schedule"></div>
