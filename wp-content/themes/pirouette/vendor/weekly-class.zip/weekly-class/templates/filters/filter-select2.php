<script type="text/x-template" id="wcs_templates_filter--select2">
  <select class='wcs-filters__filter-wrapper'>
    <slot></slot>
  </select>
</script>
