<div class='wcs-single__date'><?php echo $date; if( $multiday ) echo ' &mdash; ' . $date_ending; ?></div>
<div class="wcs-single__time-duration">
<span class='wcs-single__time'><?php echo $starting_time; if( $show_ending ) echo ' &mdash; ' . $ending_time ?></span>
