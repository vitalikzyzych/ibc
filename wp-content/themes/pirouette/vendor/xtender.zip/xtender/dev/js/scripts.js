//@codekit-prepend "../libs/bxslider/jquery.bxslider.min.js";
//@codekit-prepend "../libs/images-loaded/imagesloaded.pkgd.min.js";
//@codekit-prepend "../libs/stellar/jquery.stellar.min.js";
//@codekit-prepend "../libs/section-scroll/jquery.section-scroll.js";
//@codekit-prepend "../libs/gmaps3/gmaps3.min.js";
//@codekit-prepend "../libs/js_cookie/js_cookie.js";
//@codekit-prepend "../../assets/front/js/main-min.js";
